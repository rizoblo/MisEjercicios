package Programacion.examenmarzo;


import java.util.List;

public class ArticuloDevueltoEvent {

	
	public ArticuloDevueltoEvent() {
		
	}

	
}
