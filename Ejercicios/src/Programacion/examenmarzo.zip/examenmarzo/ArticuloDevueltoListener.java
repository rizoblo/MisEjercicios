package Programacion.examenmarzo;

public interface ArticuloDevueltoListener {
	public void articuloencontrado (ArticuloDevueltoEvent event);
}
