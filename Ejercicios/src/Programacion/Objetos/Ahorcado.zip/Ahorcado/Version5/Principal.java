package Programacion.Objetos.Ahorcado.Version5;

public class Principal {
	public static void main(String[] args) {
		ventana1 ventana=new ventana1();
		Jugador.generacionpalabra();
	}
}