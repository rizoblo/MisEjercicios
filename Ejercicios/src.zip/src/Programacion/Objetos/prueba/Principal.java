package Programacion.Objetos.prueba;

public class Principal {

	public static void main(String[] args) {
		
		Clase clase=new Clase();
		Clase2 clase2=new Clase2();
		clase.suma(5,2);
		clase.media();
		clase.impresion();
		clase2.resta();
		clase2.segundaimpresion();

	}

}
