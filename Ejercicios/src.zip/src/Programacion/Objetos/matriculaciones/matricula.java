package Programacion.matriculaciones;

public class matricula {

	private String fecha;
	private int codigo;

	public matricula() {
		super();
	}

	public matricula(String fecha, int codigo) {
		super();
		this.fecha = fecha;
		this.codigo = codigo;
		
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	

	
	


	
	
}


	


