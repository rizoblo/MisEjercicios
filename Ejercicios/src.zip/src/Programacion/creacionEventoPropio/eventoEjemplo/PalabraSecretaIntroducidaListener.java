package Programacion.creacionEventoPropio.eventoEjemplo;

public interface PalabraSecretaIntroducidaListener {

	public void palabraclaveintroducida (PalabraSecretaIntroducidaEvent event);

}
