package Programacion.creacionEventoPropio.eventoEjemplo;

public class PalabraEspecialIntroducidaAdapter implements PalabraSecretaIntroducidaListener {

	public void palabraSecretaIntroducida(PalabraSecretaIntroducidaEvent event) {
	}

	@Override
	public void palabraclaveintroducida(PalabraSecretaIntroducidaEvent event) {
		// TODO Auto-generated method stub
		
	}


}
