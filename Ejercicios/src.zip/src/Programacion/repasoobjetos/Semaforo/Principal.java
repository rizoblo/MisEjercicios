package repasoobjetos.Semaforo;

public class Principal {

	public static void main(String[] args) {
	
		Semaforo semaforo=new Semaforo();
		
		semaforo.cambiacolor();
	}

}
