package Programacion.examenmarzo;

public class ArticuloDevueltoAdapter implements ArticuloDevueltoListener {

	

	@Override
	public void articuloencontrado(ArticuloDevueltoEvent event) {
		// TODO Auto-generated method stub
		
	}




}
