package RepasoExamenListas.Juegosimulacro;

public interface PatadaListener {

	public void patadaIntroducidaJ1 (PatadaEvent event);

	public void patadaIntroducidaJ2 (PatadaEvent event);
	
}
