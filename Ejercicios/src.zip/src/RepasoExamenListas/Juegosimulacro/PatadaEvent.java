package RepasoExamenListas.Juegosimulacro;

public class PatadaEvent {
	
	public String patadaintroducida;

	public PatadaEvent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatadaEvent(String patadaintroducida) {
		super();
		this.patadaintroducida = patadaintroducida;
	}

	public String getPatadaintroducida() {
		return patadaintroducida;
	}

	public void setPatadaintroducida(String patadaintroducida) {
		this.patadaintroducida = patadaintroducida;
	}

	/**
	 * @param numeroIntroducido
	 */
	
	
}
