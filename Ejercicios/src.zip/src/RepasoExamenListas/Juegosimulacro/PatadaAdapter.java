package RepasoExamenListas.Juegosimulacro;

public class PatadaAdapter implements PatadaListener {

	//en el adapter ponemos el/los metodo/s del listener(patadaIntroducidaJ1)
	@Override
	public void patadaIntroducidaJ1(PatadaEvent event) {
		
	}

	@Override
	public void patadaIntroducidaJ2(PatadaEvent event) {
	}

}
