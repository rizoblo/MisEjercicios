package RepasoExamenListas.excepciones;

public class Capt06Bloque4Ej2exceptionnobombilla extends Exception {

	public Capt06Bloque4Ej2exceptionnobombilla() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Capt06Bloque4Ej2exceptionnobombilla(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public Capt06Bloque4Ej2exceptionnobombilla(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public Capt06Bloque4Ej2exceptionnobombilla(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public Capt06Bloque4Ej2exceptionnobombilla(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
