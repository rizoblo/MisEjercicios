package RepasoExamenListas.excepciones;

public class PiernaNulaException extends Exception {

	public PiernaNulaException(String msg) {
        super(msg);
    }
}
