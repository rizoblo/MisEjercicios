package RepasoExamenListas.excepciones;

public class PersonaNulaException extends Exception {

	public PersonaNulaException(String msg) {
        super(msg);
    }
}
