package RepasoExamenListas.Eventos.eventoEjemplo;

public class NumeroEspecialIntroducidoAdapter implements NumeroEspecialIntroducidoListener {

	@Override
	public void numeroImparIntroducido(NumeroEspecialIntroducidoEvent event) {
	}

	@Override
	public void numeroPrimoIntroducido(NumeroEspecialIntroducidoEvent event) {
	}

}
