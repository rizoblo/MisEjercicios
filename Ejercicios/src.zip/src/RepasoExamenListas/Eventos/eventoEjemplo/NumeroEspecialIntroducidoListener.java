package RepasoExamenListas.Eventos.eventoEjemplo;

public interface NumeroEspecialIntroducidoListener {

	public void numeroImparIntroducido (NumeroEspecialIntroducidoEvent event);

	public void numeroPrimoIntroducido (NumeroEspecialIntroducidoEvent event);
}
