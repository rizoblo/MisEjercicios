package RepasoExamenListas.Ejerciciosweb.Bloque7Ej1EventosyListeners;

public class DigitosEvent1 {

	String palabraintroducida;

	public DigitosEvent1() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public DigitosEvent1(String palabraintroducida) {
		super();
		this.palabraintroducida = palabraintroducida;
	}


	public String getPalabraintroducida() {
		return palabraintroducida;
	}

	public void setPalabraintroducida(String palabraintroducida) {
		this.palabraintroducida = palabraintroducida;
	}
	
	
}
