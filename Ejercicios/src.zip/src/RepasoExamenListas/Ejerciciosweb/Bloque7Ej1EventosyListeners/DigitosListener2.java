package RepasoExamenListas.Ejerciciosweb.Bloque7Ej1EventosyListeners;



public interface DigitosListener2 {

	public void digitosintroducidos (DigitosEvent1 event);
	
}
