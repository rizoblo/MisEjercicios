package examenhoy;


public class Principal {

	public static void main(String[] args) {
		Campobatalla campobatalla=new Campobatalla();
		
		/*Humano humano=new Humano();
		Malvado malvado=new Malvado();
		
		humano.calcularpuntosvidahumano();
		
		campobatalla.finalbosshumano();
		
		malvado.calcularpuntosvidamalvado();
		
		campobatalla.finalbossmalvado();
		
		campobatalla.imprimirhumanos();
		
		campobatalla.imprimirmalvados();*/
		
		//campobatalla.mezclararrayhumano();
		
		//campobatalla.mezclararraymalvado();
	
		//campobatalla.imprimirhumanos();
		
		//campobatalla.imprimirmalvados();
			
		/*campobatalla.humanodisparamalvado();
		
		campobatalla.malvadodisparahumano();

		campobatalla.comprobacionmuertohumano();
		
		campobatalla.comprobacionmuertomalvado();
		
		campobatalla.imprimirhumanos();
		
		campobatalla.imprimirmalvados();*/
		
		
	}

	
	
	
}
