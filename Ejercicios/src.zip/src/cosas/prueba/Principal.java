package prueba;

import javax.swing.JOptionPane;



public class Principal {

	public static void main(String[] args) {
		
		
		Jugador jugador= new Jugador();
		ventana ventana=new ventana();
		
		jugador.generacionpalabra();
		
		
		
		
		
		

	
	
	
	}
}