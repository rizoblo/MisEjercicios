package f1;

public class Principal {

	public static void main(String[] args) {

		Carrera carrera=new Carrera();
		carrera.imprimirvehiculos();
		
	}

}
